const fs = require('fs');

module.exports = (client) => {
    fs.readdirSync('./events/').filter((file) => file.endsWith('.js')).forEach((event) => {
      	require(`../events/${event}`);
    })

fs.readdirSync('./mongoose/').forEach(dir => {
		const files = fs.readdirSync(`./mongoose/${dir}/`).filter(file => file.endsWith('.js'));
				files.forEach((file) => {
require(`../mongoose/${dir}/${file}`)
        });
    });
};